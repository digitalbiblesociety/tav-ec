import{default as m}from"../components/pages/bibles/audio/_page.svelte-d60abd19.js";import"./index-8106616c.js";export{m as component};
