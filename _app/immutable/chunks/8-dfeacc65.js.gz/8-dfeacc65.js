import{_ as t}from"./_page-df26cdcf.js";import{default as m}from"../components/pages/films/_id_/_page.svelte-2cfa44e8.js";import"./index-8106616c.js";export{m as component,t as shared};
