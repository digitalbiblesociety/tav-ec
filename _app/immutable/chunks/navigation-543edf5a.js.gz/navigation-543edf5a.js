import{d as e}from"./singletons-62adc2b9.js";e.disable_scroll_handling;e.goto;e.invalidate;e.prefetch;e.prefetch_routes;e.before_navigate;e.after_navigate;
