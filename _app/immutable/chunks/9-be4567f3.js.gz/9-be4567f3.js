import{_ as t}from"./_page-4adc22d9.js";import{default as m}from"../components/pages/films/watch/_id_/_page.svelte-8091b8b5.js";import"./index-8106616c.js";export{m as component,t as shared};
