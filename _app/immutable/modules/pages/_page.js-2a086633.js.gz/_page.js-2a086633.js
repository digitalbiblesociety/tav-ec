import{l}from"../../chunks/_page-372489c5.js";export{l as load};
