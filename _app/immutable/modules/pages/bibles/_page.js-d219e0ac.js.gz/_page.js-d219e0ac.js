import{l}from"../../../chunks/_page-c772cbed.js";export{l as load};
