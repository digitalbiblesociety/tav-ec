import"../../../../chunks/index-fb233e95.js";import{l}from"../../../../chunks/_page-62971534.js";export{l as load};
