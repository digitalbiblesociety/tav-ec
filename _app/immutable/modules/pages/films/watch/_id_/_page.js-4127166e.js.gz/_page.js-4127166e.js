import{l}from"../../../../../chunks/_page-4adc22d9.js";export{l as load};
