import{l}from"../../../chunks/_page-3856afac.js";export{l as load};
