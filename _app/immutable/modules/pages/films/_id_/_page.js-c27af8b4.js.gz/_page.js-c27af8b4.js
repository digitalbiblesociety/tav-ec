import{l}from"../../../../chunks/_page-df26cdcf.js";export{l as load};
