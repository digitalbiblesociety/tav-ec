import{l}from"../../../chunks/_page-dc47a1c3.js";export{l as load};
