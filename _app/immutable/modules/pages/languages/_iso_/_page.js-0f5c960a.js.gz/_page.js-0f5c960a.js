import{l}from"../../../../chunks/_page-a41a99ce.js";export{l as load};
